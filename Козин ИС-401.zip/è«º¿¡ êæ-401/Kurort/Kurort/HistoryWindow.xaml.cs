﻿using Kurort.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort
{
    /// <summary>
    /// Логика взаимодействия для HistoryWindow.xaml
    /// </summary>
    public partial class HistoryWindow : Window
    {
        DispatcherTimer timer;
        public HistoryWindow()
        {
            InitializeComponent();
            //Огранизация таймера
            TimeSpan time = TimeSpan.FromSeconds(GlobalTimer.Seconds);
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
            //Вывод историй в лист
            listHistory.ItemsSource = App.db.HistoryJoins.ToList();
            sortCmb.Items.Add(new User() { Login = "Всё"});
            foreach (var user in App.db.Users)
            {
                sortCmb.Items.Add(user);
            }
        }
        //Метод для таймера
        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (GlobalTimer.Seconds <= 0)
            {
                timer.Stop();
                GlobalTimer.Reset();
                MainWindow main = new MainWindow();
                main.Left = this.Left;
                main.Top = this.Top;
                main.Show();
                this.Close();
            }
            if (GlobalTimer.Seconds == 60)
            {
                GlobalTimer.MessageExit();
            }
            GlobalTimer.Seconds = GlobalTimer.Seconds - 1;
            TimeSpan time = TimeSpan.FromSeconds(GlobalTimer.Seconds);
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
        }

        private void closeBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            this.Close();
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }
        //Метод для возврата на предыдщее окно
        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            MenuWindows menu = new MenuWindows();
            menu.Left = this.Left;
            menu.Top = this.Top;
            menu.Show();
            this.Close();
        }
        //Метод для сортировки по логину
        private void sortCmb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sortCmb.SelectedIndex == -1)
                return;
            if (sortCmb.SelectedIndex == 0)
            {
                listHistory.ItemsSource = App.db.HistoryJoins.ToList();
                return;
            }
            List<HistoryJoin> sortl = new List<HistoryJoin>();
            foreach (var history in App.db.HistoryJoins)
            {
                if (history.Login == sortCmb.SelectedValue.ToString())
                    sortl.Add(history);
            }
            listHistory.ItemsSource = sortl;
        }
    }
}
