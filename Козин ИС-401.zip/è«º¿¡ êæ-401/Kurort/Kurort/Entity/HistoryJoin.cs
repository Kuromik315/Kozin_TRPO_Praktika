﻿using System;
using System.Collections.Generic;
using System.Windows.Media;

namespace Kurort.Entity;

public partial class HistoryJoin
{
    public int IdHistory { get; set; }

    public string Login { get; set; } = null!;

    public DateTime DateInput { get; set; }

    public string Status { get; set; } = null!;
    public Brush brush
    {
        get
        {
            if (Status == "Успешно")
                return Brushes.Green;
            return Brushes.Red;
        }
    }

    public int IdUser { get; set; }

    public virtual User IdUserNavigation { get; set; } = null!;
}
