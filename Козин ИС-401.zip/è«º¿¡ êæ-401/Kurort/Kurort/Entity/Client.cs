﻿using System;
using System.Collections.Generic;

namespace Kurort.Entity;

public partial class Client
{
    public int ClientCode { get; set; }

    public string Surname { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Lastname { get; set; } = null!;
    public string FullName { get { return Surname + " " + Name + " " + Lastname; } }

    public long Passport { get; set; }

    public DateOnly Birthday { get; set; }

    public string Address { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Password { get; set; } = null!;

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
