﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kurort.Entity
{
    public class ItemService
    {
        public Service Service { get; set; }
        public bool isChecked {  get; set; } = false;
    }
}
