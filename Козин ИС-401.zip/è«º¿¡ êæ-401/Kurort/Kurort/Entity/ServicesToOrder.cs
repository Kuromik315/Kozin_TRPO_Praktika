﻿using System;
using System.Collections.Generic;

namespace Kurort.Entity;

public partial class ServicesToOrder
{
    public int IdServOrder { get; set; }

    public int IdOrder { get; set; }

    public int IdService { get; set; }

    public virtual Order IdOrderNavigation { get; set; } = null!;

    public virtual Service IdServiceNavigation { get; set; } = null!;
}
