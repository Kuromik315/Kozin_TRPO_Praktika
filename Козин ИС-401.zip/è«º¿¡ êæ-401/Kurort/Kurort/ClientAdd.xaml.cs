﻿using Kurort.Pages;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort
{
    /// <summary>
    /// Логика взаимодействия для ClientAdd.xaml
    /// </summary>
    public partial class ClientAdd : Window
    {
        public DispatcherTimer timer;
        public ClientAdd()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }
        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (GlobalTimer.Seconds <= 0)
            {
                timer.Stop();
                GlobalTimer.Reset();
                MainWindow main = new MainWindow();
                main.Left = this.Left;
                main.Top = this.Top;
                main.Show();
                Window window = Owner;
                this.Close();
                window.Close();
            }
            if (GlobalTimer.Seconds == 60)
            {
                GlobalTimer.MessageExit();
            }
            GlobalTimer.Seconds = GlobalTimer.Seconds - 1;
        }

        private void closeBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            this.Close();
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }
    }
}
