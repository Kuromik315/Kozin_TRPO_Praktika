﻿using Kurort.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort.Pages
{
    /// <summary>
    /// Логика взаимодействия для itogOrder.xaml
    /// </summary>
    public partial class itogOrder : Page
    {
        Client curClient;
        List<int> idServ;
        public itogOrder(int code, List<int> services)
        {
            InitializeComponent();
            //Вывод итоговых данных по созданию заказа
            idServ = services;
            curClient = App.db.Clients.Where(x => x.ClientCode == code).FirstOrDefault();
            txtNameClient.Text = curClient.FullName;
            List<Service> selserv = new List<Service>();
            foreach (var item in services)
            {
                Service service = App.db.Services.Where(x => x.IdService == item).FirstOrDefault();
                selserv.Add(service);
            }
            listService.ItemsSource = selserv;
        }
        public void UpdateTime(TimeSpan time)
        {
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
        }

        private void nextBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(timeTxt.Text, out int a))
            {
                MessageBox.Show("Минуты введены неверно!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                //Создания нового заказа и добавление его в БД
                int minuts = int.Parse(timeTxt.Text);
                Order newOrder = new Order();
                newOrder.RentalTime = minuts;
                newOrder.CreateDate = DateTime.Now.Date;
                newOrder.ClientCode = curClient.ClientCode;
                newOrder.IdStatus = ((Status)App.db.Statuses.Where(x => x.Name == "Новая").FirstOrDefault()).IdStatus;
                newOrder.ClosedDate = null;
                newOrder.CreateTime = TimeOnly.FromDateTime(DateTime.Now);
                newOrder.CodeOrder = $"{curClient.ClientCode}/{newOrder.CreateDate}";
                App.db.Orders.Add(newOrder);
                App.db.SaveChanges();
                newOrder = App.db.Orders.Where(x => x.CodeOrder == newOrder.CodeOrder).FirstOrDefault();
                //Создание таблиц для услуг в заказе
                foreach (var item in idServ)
                {
                    App.db.ServicesToOrders.Add(new ServicesToOrder() 
                    { IdOrder = newOrder.IdOrder, IdService = item });
                }
                App.db.SaveChanges();
                MessageBox.Show("Заказ оформлен успешно!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                AddOrderWin window = (AddOrderWin)Window.GetWindow(this);
                MenuWindows menu = new MenuWindows();
                menu.Left = window.Left;
                menu.Top = window.Top;
                menu.Show();
                window.timer.Stop();
                window.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Возникла ошибка: {ex.Message}", "Внимание", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
