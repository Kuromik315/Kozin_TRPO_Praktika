﻿using Kurort.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort.Pages
{
    /// <summary>
    /// Логика взаимодействия для ServiceSelect.xaml
    /// </summary>
    public partial class ServiceSelect : Page
    {
        List<ItemService> itemServices;
        int code;
        public ServiceSelect(int clientCode)
        {
            InitializeComponent();
            TimeSpan time = TimeSpan.FromSeconds(GlobalTimer.Seconds);
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
            code = clientCode;
            itemServices = new List<ItemService>();
            //Вывод услуг в лист, использует специальный класс для использования CheckBox
            foreach (var item in App.db.Services)
            {
                itemServices.Add(new ItemService() { Service = item });
            }
            serviceList.ItemsSource = itemServices;
        }
        public void UpdateTime(TimeSpan time)
        {
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
        }
        //Открытие следующей страницы, которой передаются все данные необходимые для формирования заказа 
        private void nextBtn_Click(object sender, RoutedEventArgs e)
        {
            List<int> services = new List<int>();
            foreach (var item in itemServices)
            {
                if (item.isChecked)
                    services.Add(item.Service.IdService);
            }
            itogOrder order = new itogOrder(code, services);
            if (services.Count == 0)
            {
                MessageBox.Show("Ни одна услуга не выбрана!", "Выберите услугу", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigationService.Navigate(order);
        }
        //Кнопка возврата
        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
        //Метод поиска услуг
        private void searchTxt_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            string search = searchTxt.Text.ToLower();
            List<ItemService> itemServicesSearch = new List<ItemService>();
            foreach (var item in itemServices)
            {
                if (item.Service.Name.ToLower().Contains(search))
                    itemServicesSearch.Add(item);
            }
            serviceList.ItemsSource = itemServicesSearch;
        }
    }
}
