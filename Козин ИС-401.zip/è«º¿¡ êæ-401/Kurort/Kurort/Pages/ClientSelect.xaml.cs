﻿using Kurort.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientSelect.xaml
    /// </summary>
    public partial class ClientSelect : Page
    {
        public ClientSelect()
        {
            InitializeComponent();
            TimeSpan time = TimeSpan.FromSeconds(GlobalTimer.Seconds);
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
            //Привязка списка к клиентам в бд
            clientList.ItemsSource = App.db.Clients.OrderBy(x => x.Surname).ToList();
        }

        public void UpdateTime(TimeSpan time)
        {
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
        }

        //Возврат на предыдущее окно
        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            AddOrderWin parent = (AddOrderWin)Window.GetWindow(this);
            parent.timer.Stop();
            MenuWindows menu = new MenuWindows();
            menu.Left = parent.Left;
            menu.Top = parent.Top;
            menu.Show();
            parent.Close();
        }
        //Метод поиска
        private void searchTxt_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            List<Client> searchList = new List<Client>();
            string search = searchTxt.Text.ToLower();
            foreach (var client in App.db.Clients)
            {
                if (client.FullName.ToLower().Contains(search))
                    searchList.Add(client);
            }
            clientList.ItemsSource = searchList.OrderBy(x => x.Surname);
        }
        //Переход на следующее окно, выбранный клиент передаётся на след страницу
        private void nextBtn_Click(object sender, RoutedEventArgs e)
        {
            if (clientList.SelectedIndex == -1)
            {
                MessageBox.Show("Клиент не выбран!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            Client selClient = clientList.SelectedItem as Client;
            ServiceSelect sersel = new ServiceSelect(selClient.ClientCode);
            NavigationService.Navigate(sersel);
        }
        //Вызов окна добавления клиента
        private void addcleintBtn_Click(object sender, RoutedEventArgs e)
        {
            AddOrderWin orderWin = (AddOrderWin)Window.GetWindow(this);
            orderWin.timer.Stop();
            ClientAdd clientAdd = new ClientAdd();
            clientAdd.Closing += ClientAdd_Closing;
            clientAdd.Owner = orderWin;
            clientAdd.ShowDialog();
            clientList.ItemsSource = App.db.Clients.OrderBy(x => x.Surname).ToList();

        }

        private void ClientAdd_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            AddOrderWin orderWin = (AddOrderWin)Window.GetWindow(this);
            orderWin.timer.Start();
        }
    }
}
